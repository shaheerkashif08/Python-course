'''A spam comment is defined as a text containing following keyword:
"Make a lot of money", "Subscribe this", "Click this", "Buy now". Write a program to detect these scam'''

p1 = "Make a lot of money"
p2 = "Subscribe this"
p3 = "Click this"
p4 = "Buy now"
message = input("Enter your comment")
print(message)

if((p1 in message) or (p2 in message) or (p3 in message) or (p4 in message)):
    print("This comment is totally SCAM!")

else:
    print("This comment is OK ")