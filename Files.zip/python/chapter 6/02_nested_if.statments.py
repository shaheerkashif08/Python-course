age = int(input('Enter your age: '))
# if statment no:1
if(age%2 == 0):
    print("age is even")

# if statment no: 2
if(age>=18):
    print("You are an adult")

elif(age==18):        
    print("Just an adult")

elif(age==0):   
    print("you are entering 0 which is invalid age ")    

elif(age<=0):
    print('You are entering invalid age')

else:
    print("You are a child")