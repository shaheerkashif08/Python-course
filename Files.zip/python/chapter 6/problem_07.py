# Write a program to find out whaether the given post is talking about "Harry" or not

post = input("Write the caption: ")

if("Harry".lower() in post.lower()):
    print("This post is talking about Harry")

else:
    print("This post is not talking about Harry")