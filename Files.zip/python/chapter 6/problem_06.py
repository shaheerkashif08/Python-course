# Write a program to calculate of student from his marks

eng = int(input("Write English marks: "))
math = int(input("Write Maths marks: "))
sci = int(input("Write Science marks: "))
urdu = int(input("Write Urdu marks: "))

total = eng+math+sci+urdu
print(total)

total_percentage = (total)/400 *100
print(total_percentage)

if(total_percentage>=90):
    print("Your Grade is: A++")

elif(total_percentage>=80):
    print("Your Grade is: A+")

elif(total_percentage>=70):
    print("Your Grade is: A")

elif(total_percentage>=60):
    print("Your Grade is: B")

elif(total_percentage>=50):
    print("Your Grade is: C")

else:
    print("You are Failed in Exam")