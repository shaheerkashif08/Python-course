# Write a program which find out whether th given username is present in list or not
username = ["Akash", "Shahveer", "Ali", "Talha", "Shariq"]
name = input("Enter your name: ")

if((name in username)):
    print(f"your name: {name} is in list")

else:
    print(f"your name: {name} is not in list")