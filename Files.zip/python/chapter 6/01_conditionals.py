name = input("Ente your name: ")
age = int(input("Enter your age: "))
if(age>=18):
    print("You are an adult")

elif(age==18):        
    print("Just an adult")

elif(age==0):   
    print("you are entering 0 which is invalid age ")    

elif(age<=0):
    print('You are entering invalid age')

else:
    print("You are a child") 