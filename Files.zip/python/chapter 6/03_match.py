a = int(input("Enter your lucky number"))

match a:
    case 1:
        print("You won a Q mobile charge")
    case 2:
        print("You won a moto bike")

    case 4:
        print("You won a Golden duck")
    case 5:
        print("You won a PC")
 
    case 8:
        print("You won an Umrah package")
    case 9:
        print("You won a smart phone")
    case _:
        print("Better luck next time")
print("End of program")