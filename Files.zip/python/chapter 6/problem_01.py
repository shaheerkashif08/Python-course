# Write a program to find the greatest of four numbers entered by user
a1 = 54
a2 = 31
a3 = 76
a4 = 34

if(a1>a2 and a1>a3 and a1>a4):
    print("a1 is greatest of all number ", a1)

elif(a2>a1 and a2>a3 and a2>a4):
    print("a2 is greatest of all number ", a2)
    

elif(a3>a1 and a3>a2 and a3>a4):
    print("a3 is greatest of all number ", a3)

elif(a4>a1 and a4>a2 and a4>a3):
    print("a4 is greatest of all number: ", a4)
