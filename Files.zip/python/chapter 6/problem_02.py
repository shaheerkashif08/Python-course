'''Write a rogram to find out whether a student hs passed or failed if it require a total of 40% and at 
least 33% in each subject to pass. Assume 3 subject and take marks as input from user'''

eng = int(input("Write English marks: "))
math = int(input("Write Maths marks: "))
sci = int(input("Write Science marks: "))

total = eng+math+sci
print(total)

total_percentage = (total)/300 *100
print(total_percentage)
if(total_percentage>=40):
    print("You have passed the exam sucessfully")

else:
    print("you Failed, try again next time! ")

    # for English subject    
if(eng>=33):
    print("You passed english exam")

else:
    print("You failed in English exam")

    # For Math subject
if(math>=33):
    print("You passed Maths exam")

else:
    print("You failed in Maths exam")
    
if(sci>=33):
    print("You passed Science exam")

else:
    print("You failed in Science exam")
   