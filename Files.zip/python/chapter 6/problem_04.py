# Write a program to check whether the given username contain less than 10 characters or not.
username = input("Enter the username: ")

if(len(username)>10):
    print("The username contain more than 10 characters")

elif(len(username)==10):
    print("Username contain 10 characters")

else:
    print("The username contain less than 10 characters")