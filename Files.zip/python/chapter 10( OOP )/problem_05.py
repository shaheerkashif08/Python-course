# Write a class Train which has method to book a ticket, get status(no of seat) and get a fare information of train running under Pindi Express
from random import randint

class Train:

    def __init__(self, train_no, fro, to):
        self.train_no = train_no
        self.fro = fro
        self.to = to

    def book_ticket(self):
        print(f"Ticket is booked in Train no: {self.train_no} from {self.fro} to {self.to} ")

    def check_status(self):
        print(f"Train no: {self.train_no} is running on time")

    def get_fare(self):
        print(f"Ticket is booked in Train no: {self.train_no} from {self.fro} to {self.to} and it's seat no is: {randint(4501, 5521)} ")

t = Train(randint(4501, 7743), "Abbotabad", "Jamshoro")
t.book_ticket()
t.check_status()
t.get_fare()