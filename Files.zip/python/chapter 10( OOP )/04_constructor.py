class Car:
    brand = "Audi"
    speed =  285
    engine = "Turbo fuel stratified engine"
    pricing = "5 Cr"

    def __init__(self, brand, speed, engine, pricing):    # dunder method are automatically called
        self.brand = brand
        self.speed = speed
        self.engine = engine
        self.pricing = pricing
        print("Information getting about your dream car")


    def get_info(self):
        print(f"The brand of modern car is {self.brand}. It's top speed goes to {self.speed}km/h & engine in it is {self.engine}")

    @staticmethod
    def greet():
        print("Good Morning")

car = Car("BMW",305, "Twin turbo V-8 engine", "4.5 Cr" )
# car.pricing = "4.5 Cr"
print(car.brand,car.pricing,car.speed,car.engine)