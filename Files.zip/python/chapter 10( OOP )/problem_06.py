# Can you change the self parameter inside a class to something else ("say harry"). Try  changing self to 'sif' or 'harry' and see the effect

from random import randint

class Train:

    def __init__(slf, train_no, fro, to):
        slf.train_no = train_no
        slf.fro = fro
        slf.to = to

    def book_ticket(slf):
        print(f"Ticket is booked in Train no: {slf.train_no} from {slf.fro} to {slf.to} ")

    def check_status(slf):
        print(f"Train no: {slf.train_no} is running on time")

    def get_fare(slf):
        print(f"Ticket is booked in Train no: {slf.train_no} from {slf.fro} to {slf.to} and it's seat no is: {randint(4501, 5521)} ")

t = Train(randint(4501, 7743), "Abbotabad", "Jamshoro")
t.book_ticket()
t.check_status()
t.get_fare()