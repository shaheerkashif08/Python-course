class Employee:
    # name = "Shaheer"
    lang = "Python"  # this is a class attribute
    salary = "120000"  # this is a class attribute 

harry = Employee()
harry.name = "Harry"   # This is an instance attribute
print(harry.name, harry.salary, harry.lang)

rohan = Employee()
rohan.name = "Rohan RoRo robinson"   # This is an instance attribute
print(rohan.name, rohan.lang, rohan.salary)

# Here name are object attribute and slary and lang are class attributes as they aredirectly belongs to class attributes
