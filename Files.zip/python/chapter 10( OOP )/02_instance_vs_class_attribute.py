class Employee:
    lang = 'python'
    salary = '120000'

harry = Employee()
harry.lang = 'Java'    # instance attribute preference over class attribute
print(harry.lang,harry.salary)