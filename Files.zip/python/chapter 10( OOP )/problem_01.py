# Create a class "programmer" for storing information of few programmer working at microsoft

class programmer:
    company = "Microsoft"
    def __init__(self,name, age, salary, lang):
        self.name = name
        self.age = age
        self.salary = salary
        self.lang = lang 

shaheer = programmer("Shaheer",20, 120000, "Python")
# shaheer.lang = "Java"
print(shaheer.name, shaheer.age, shaheer.company,shaheer.salary,shaheer.lang)

farhan = programmer("Farhan", 15, 15000,None)
print(farhan.name, farhan.age, farhan.company,farhan.salary,farhan.lang)

saba = programmer("Saba", 19, 95000, "php")
print(saba.name, saba.age, saba.company,saba.salary,saba.lang)