class Car:
    brand = "BMW"
    speed =  305
    engine = "Twin turbo V-8 engine"

    def get_info(self):
        print(f"The brand of modern car is {self.brand}. It's top speed goes to {self.speed}km/h & engine in it is {self.engine}")

    @staticmethod
    def greet():
        print("Good Morning")
car = Car()
# Car.get_info(car)
car.get_info()
Car.greet()