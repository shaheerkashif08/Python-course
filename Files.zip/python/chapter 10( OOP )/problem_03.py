# Craeate a class attribute a:create an object from it and set "a" directly using object.a = 0. Does this change the class attribute?

class Demo:
    a = 5

o = Demo()
print(o.a)   #Prints the class attribute b/c instance attribute not present

o.a = 0   # Instance attribute set
print(o.a)   # Prints the instance attribute b/c instance attribute present

print(Demo.a)   # class attribute is not changed as in above it changinge instance attribute