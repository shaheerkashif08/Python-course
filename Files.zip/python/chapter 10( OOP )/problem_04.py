# Add a static method in problem 2, to greet the user with hello

class Calculator:
    def __init__(self, n):
        self.n = n

    def square(self):
        sq = self.n**2
        print(f"The square of given number is {sq}")

    def sq_root(self):
        sq_root = self.n**0.5
        print(f"The square root of given number is {sq_root}")

    def cube(self):
        cube = self.n**3
        print(f"The square of given number is {cube}")

    @staticmethod
    def greet():
        print("Hello!")


a = Calculator(16)
a.greet()     
a.square()
a.sq_root()
a.cube()