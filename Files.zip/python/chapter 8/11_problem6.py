# Write a python function which convert inches to cm.

inch = 10

def convers(inch):
    return inch * 2.54

print(convers(inch))