def Goodday(name, ending="Thank you"):
    print("GoodDay, " + name)
    print(ending)

Goodday("Shaheer", "Thanks jani")
Goodday("Fuzail")