# Write a program to find the greatest of three numbers using a function

a = int(input("Enter the first number: "))
b = int(input("Enter the second number: "))
c = int(input("Enter the third number: "))

def greatest():
    if(a>b and a>c):
        print(f"The greatest number is {a} ")
    elif(b>a and b>c):
        print(f"The greatest number is {b} ")
    else:
        print(f"The greatest number is {c} ")

greatest()