def Goodday(name, ending):
    print("GoodDay, " + name)
    print(ending)

Goodday("Shaheer", "Thank You!")
Goodday("Fuzail", "Thank You!")
Goodday("Sana", "Thank You!")