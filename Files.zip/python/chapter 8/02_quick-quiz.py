def goodday():
    return "Good Day"

gender = input("Enter your gender: ")
name = input("Enter your Full name: ")

if(gender=='male'):
    print(f"{goodday()} Sir, {name}.")

else:
    print(f"{goodday()} Miss, {name}.")