# Function defination
def avg():
    a = int(input("Enter the number"))
    b = int(input("Enter the number"))
    c = int(input("Enter the number"))

    average = (a+b+c)/3
    print(average)

# Function call
avg()
print("Thank You!")
avg()
print("Thank You!")
avg()
avg()
print("Thank You!")
avg()
