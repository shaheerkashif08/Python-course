# Write a program to convert celsius temperature into farenheit using function

far = float(input("Enter the temperature here: "))

def temp(cel):
    cel = 5/9 * (far - 32)
    return cel

cel = temp(far)
print(f'The temperature in celsius is : {round(cel , 2)}°C ')