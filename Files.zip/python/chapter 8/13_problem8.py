# write a python function to print multiplication table of a given number

n = int(input("Enter the number of multiplication table: "))
def table(n):
    print(f"Multiplicaion Table of {n} is ")
    for i in range(1, 11):
        print(f"{n} * {i} = {n*i}")

table(n)