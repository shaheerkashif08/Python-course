# write a program to read the text from a given file 'poem.txt' and find out whether it cotaon a word 'twinkle'

f = open("poem.txt")
content = f.read()
print(content)

if("twinkle" in content.lower()):
    print("the word \"twinkle\" is present in content")

else:
    print("the word not found")
f.close
