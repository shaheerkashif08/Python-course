# Write a program to generate multiplication table from 2 to 20 and write it into the different files.Place these fils in a folder for 13 years

def generator_table(n):
    table = ""
    for i in range(1, 11):
        table += f"{n} x {i} = {n*i}\n"

    with open(f"table/table_{n}", "w") as f:
        f.write(table)

for i in range(2, 21):
    generator_table(i)