# The game() function in a program lets a user play a game and returns the score as integer. You need to read a file 'High-score.txt' which is either blank or contain the previous Hi-score. You need to write a program to update a high score whenever game() function break the high score.  
import random

def game():
    print("You are playig a game...")
    score = random.randint(1, 62)

    with open("hiscore.txt") as f:
        hiscore = f.read() 
        if(hiscore!=""):
            hiscore=int(hiscore)

        else:
            hiscore = 0

    print(f"Your score: {score}")
    if(score>hiscore or hiscore==""):

        with open("hiscore.txt", "w") as f:
            f.write(str(score))

    return score

game()