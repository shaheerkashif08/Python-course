# Write a program to make a copy file of "file.txt"

with open("file.txt") as f:
    content = f.read()

with open("new_file.txt", "w") as f:
    f.write(content)