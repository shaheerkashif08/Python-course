f = open("file.txt")
data = f.read()
print(data)
f.close()