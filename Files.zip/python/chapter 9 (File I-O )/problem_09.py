# Write a program to find out whether a file is identical and matches the content of another file

with open("file.txt") as f:
    content1 = f.read()

with open("new_file.txt") as f:
    content2 = f.read()

if(content1 == content2):
    print("Yes files are identical to each other " )

else:
    print("files are not identical to each other " )
