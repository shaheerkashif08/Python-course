# write a program to mine a log file and find out whether it contain 'python'
with open("donkey.txt", "r") as f:
    content = f.read()

if('python' in content):
    print("The word python is present")

else:
    print("the word is not present")