# Reapeat program 4 for  a list of such words to be censored.
words = ["donkey" , "horse" , "lion"]
# words = [w.lower() for w in word]


with open("donkey.txt", "r") as f:
    content = f.read().lower()

for word in words:
    content= content.replace(word, '#' * len(word))

with open("donkey.txt", "w") as f:
    f.write(content)