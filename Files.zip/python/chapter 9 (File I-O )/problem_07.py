# write a program to find out the line number of python in ques no 6
with open("donkey.txt", "r") as f:
    lines = f.readlines()

line_no = 1
for line in lines:
    if('python' in line):
        print(f"The word python is present in line no:{line_no}")
        break
    line_no += 1

else:
    print("the word is not present")
