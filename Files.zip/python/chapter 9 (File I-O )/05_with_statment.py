# f = open("file.txt")
# print(f.read)
# f.close()

# same work can be done using with statment wiithout putting f.close() statment

with open("file.txt") as f:
    print(f.read())

print(f)