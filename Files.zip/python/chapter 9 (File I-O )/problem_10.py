# write a progam to wipe out the content of a file using python

with open("my_files.txt", "w") as f:
    f.write("")