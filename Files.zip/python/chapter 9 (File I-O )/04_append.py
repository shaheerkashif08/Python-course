st = " Hey harry this course is amazing and helped me lot to becomea web developer "
f = open("my_files.txt", "a")

f.write(st)
f.close()