print('''Twinkle Twinkle little star
How were wonder what you are 
up the sky like a diamond in the sky
Twinkle Twinkle little star ''')