t = input("Enter your Name:")
print(t)