# Hey my name is Shaheer (single line comment)
'''print("I am a begginer in programing 
THis is my first ever experience.
And I'm glad to know more about python")''' #(for multi line comment)