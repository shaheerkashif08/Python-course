class Employee:
    a=1

    @classmethod
    def show(cls):
        print(f"The class value of a is {cls.a}")

    @property
    def name(self):
        return f"{self.fname} {self.lname}"

    @name.setter
    def name(self, value):
        self.fname = value.spilit(" ")[0]
        self.fname = value.spilit(" ")[0]

e = Employee()
e.a = 45
e.name = "harry khan"
print(e.name)

e.show()