# Create a class 'Employee' and add salary andincrement properies to it.
# Write a method "salaryAlterIncrement" method with a @property decorator with a setter which changes the valueof increment base on the salary

class Employee:
    salary = 2000
    increment = 70

    @property
    def SalaryAlterIncrement(self):
        return (self.salary + self.salary * (self.increment/100))

    @increment.setter
    def increment(self):
        
    

e1 = Employee()
print(e1.SalaryAlterIncrement)