# craete a class = "Pets" from a class = "Animals" and furthur crete a class "Dog" from "Pets". Add a method "bark" to class "Dog".

class Animals:
    pass

class Pets(Animals):
    pass

class Dog(Pets):
    @staticmethod
    def bark():
        print("bow bow!")

d = Dog()
d.bark()