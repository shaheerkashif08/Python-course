# Write __str__() method tp print the vector a follows:
#         7i + 8j + 10k
# Assume vector of dimension  for this problem