class Employee:
    company = "IBM"
    def show(self):
        print(f"The name of the employee is {self.name} and the salary is {self.salary}")

class Programmer(Employee):
    company = "IBM Infotech"
    def showLanguage(self):
        print(f"The name of the employee is {self.name} and he is good in {self.language} language")

a = Employee()
b = Programmer()

print(a.company, b.company)