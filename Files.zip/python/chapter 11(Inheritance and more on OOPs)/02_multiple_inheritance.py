class Employee:
    company = "IBM"
    name = "Krishna"
    salary = 350000
    def show(self):
        print(f"The name of the employee is {self.name} and the salary is {self.salary}")

class Coderr:
    language = "Java"
    def printLanguages(self):
        print(f"Out of your language here is your language: {self.language}")

class Programmer(Employee, Coderr):
    company = "IBM Infotech"
    def showLanguage(self):
        print(f"The name of the employee is {self.name} and he is good in {self.language} language")

a = Employee()
b = Programmer()

b.show()
b.showLanguage()
b.printLanguages()