class Employee:
    a = 4
    def __init__(self):
        print("Constructor of Employee")

class Programmer(Employee):
    def __init__(self):
        print("Constructor of Programmer")
    b = 7

class Assistant(Programmer, Employee):
    def __init__(self):
        super().__init__()
        print("Constructor of Assistant")
    c = 9

# o = Employee()
# print(o.a)
#print(0.b)         # This will show an eror

# o = Programmer()
# print(o.a, o.b)

o = Assistant()
print(o.a, o.b, o.c)