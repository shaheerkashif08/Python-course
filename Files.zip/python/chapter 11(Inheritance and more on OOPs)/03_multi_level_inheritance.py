class Employee:
    a = 4

class Programmer(Employee):
    b = 7

class Assistant(Programmer, Employee):
    c = 9

o = Employee()
print(o.a)
#print(0.b)         # This will show an eror

o = Programmer()
print(o.a, o.b)

o = Assistant()
print(o.a, o.b, o.c)