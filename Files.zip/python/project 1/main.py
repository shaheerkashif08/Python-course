import random
'''
1 for rock
-1 for paper 
0 for scissor
'''
computer = random.choice([1,-1,0])
youstr = input("Enter your choice: ")
youDict  = {"r": 1, "p": -1, "s": 0}
reverseDict = {1: "rock", -1: "paper", 0: "scissor"}

you = youDict[youstr]
print(f"You Choose {reverseDict[you]}\n And Computer Choose {reverseDict[computer]}")

if(computer == you):
    print("Match tied! ")

else:
    if(computer == 1 and you == -1):
        print("You win! ")
    elif(computer==1 and you==0):
        print("You lose! ")
    
    elif(computer==-1 and you==1):
        print("You lose! ")
    elif(computer==-1 and you==0):
        print("You Win! ")

    elif(computer==0 and you==1):
        print("You Win! ")
    elif(computer==0 and you==-1):
        print("You lose! ")

    else:
        print("something went wrong")