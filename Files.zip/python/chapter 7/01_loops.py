print(1)
print(2)
print(3)
print(4)
print(5)

# same thing can ve dune by loop
for i in range(1, 6):
    print(i)