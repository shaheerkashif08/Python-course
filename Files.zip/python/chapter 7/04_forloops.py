for i in range(4):
    print(i)

for i in range(0, 100, 4):
    print(i)