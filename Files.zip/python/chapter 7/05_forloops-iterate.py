l = [34, 765, 46, 967, 54]

for i in l:
    print(i)

t = (65, 786, 3, 28, 673)
for i in t:
    print(i)

s = "Shaheer"
for i in s:
    print(i)