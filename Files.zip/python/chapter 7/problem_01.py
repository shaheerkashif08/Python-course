# write a program to print multiplication table of a given number using for loop and while loop

n = int(input("Enter the number: "))
for i in range(1, 11):
    print(f"{n} x {i} = {n * i}")


m = int(input("Enter your number: "))
i = 1
while i < 11:  # Change condition to i <= 10
    print(f"{m} x {i} = {m * i}")
    i += 1  # Increment i to eventually exit the loop
