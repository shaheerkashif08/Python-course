'''Write a program to get following star 
                *
               ***
              *****
                       '''

# Number of rows in the pattern
n = int(input("Enter the number"))

for i in range(1, n + 1):
    # Print leading spaces
    print(" " * (n - i), end="")
    # Print stars
    print("*" * (2 * i - 1), end="")
    print("")


