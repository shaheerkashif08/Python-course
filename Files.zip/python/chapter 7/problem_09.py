n = 5

for i in range(1, 11):
    print(f"{n} x {11 - i} = {n * (11-i)}")

m = 4
for i in range(10, 0, -1):
    print(f"{m} x {i} = {m * i}")