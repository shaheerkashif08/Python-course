# Write a program to find out sum of first 10 natural number 

n = int(input("Enter the number:  "))
i = 1 
sum = 0

while i <= n:
    sum += i
    i += 1

print(f"The sum of first {n} natural numbers is: ", sum )
