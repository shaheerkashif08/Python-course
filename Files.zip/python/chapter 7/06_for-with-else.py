l = [3,65,28,44,7]
for item in l:
    print(item)

else:
    print("Done")