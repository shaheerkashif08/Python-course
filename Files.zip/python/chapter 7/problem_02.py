# Write a program to greet all the person name stored in a list 'l' and which start with S 

l = ["Harry", "Shaheer", "Sachin", "Purvi", "Salunkhe"]
for name in l:
    if(name.lower().startswith("s")):    # for case sentivity we can add lower case here
        print(f"Hello Good Afternoon, sir {name} ")
    