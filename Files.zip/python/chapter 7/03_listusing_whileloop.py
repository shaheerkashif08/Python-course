l = [1, False, "Harry", "Shahee", "numair", 24.286, {1,2}]

i = 0
while(i<len(l)):
    print(l[i])
    i = i+1