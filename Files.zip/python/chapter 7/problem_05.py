# Write a program to find factorial of given number 

n = int(input("Enter the number:  "))
i = n
s = 1

while i >= 1:
    s *= i
    i -= 1
print("The factorial of given number is:", s)


product = 1
for i in range(1, n+1):
    product = product * i

print(product)