for i in range(100):
    if(i==34):
        break # Exit the loop instantly
    print(i)

for i in range(100):
    if(i==34):
        continue # Skip the iteration 
    print(i)

for i in range(654):
    pass  # skip the current loop

i = 0
while(i<45):
    i +=1
    print(i)