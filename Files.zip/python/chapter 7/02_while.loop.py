i = 1
while(i<51):
    print(i)
    i += 1
    if(i==47):
        break
    
    elif(i==32):
        pass
    elif(i==43):
        continue