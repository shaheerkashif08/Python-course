name = "SHAHEER"
nameshort = name[0:4] # start from index 0(included) till 4(excluded)
print(nameshort)

character1 = name[2]
print(character1)

namelenght = len(name)
print(namelenght)

# negative slicing in a string
name = 'ALI mota'
print(name[-4:-1])
print(name[4:8])

# skiping the values in string
a = "abcdefghijklmnop"
print(a[1:9:3])
