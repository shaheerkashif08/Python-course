a = 'Shaheer Aashif'
print(len(a)) # to find the lenght of string
print(a.endswith('hif')) # To check whether the string ends with 
print(a.startswith("sha")) #  To check whether the string starts with 
print(a.capitalize()) # To capitalize the very first letter of first word only
print(a.title()) # To capitalize the first letter of every words
print(a.upper()) # To capitalize the every single word of string
print(a.lower()) # To uncapitalize the every single word of string
print(a.replace('Aashif' , 'Kashif')) #To replce a wprd in string 
print(a.split()) # To split the every word
print(" ".join(a)) # To make a gap in every alphabet of words
print(a.count('a')) # To count the alphabets in string

name = "John"
age = 30
text = "My name is {} and I am {} years old".format(name, age)
print(text)  # to make a format 
