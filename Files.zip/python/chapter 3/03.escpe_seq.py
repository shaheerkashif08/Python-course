# Newline
print("Hello\nWorld")


# Tab
print("Name:\tAlice")


# Backslash
print("This is a backslash: \\")


# Single and double quotes
print('It\'s a sunny day.')
print("She said, \"Hello!\"")


# Backspace
print("Hello \bWorld")


# Carriage return
print("Hello\rWorld")


# Octal and hexadecimal values
print("\101")  # Octal for 'A'
print("\x41")  # Hexadecimal for 'A'
