# Write a python program to display a user name entered name followed by Good afternoon using input function 

name = input("Enter your name: ")

print(f"Good Afternoon {name} ")