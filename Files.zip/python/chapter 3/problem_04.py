name = "Shaheer is a tall  and  handsome boy"
print(name.replace("  " , " "))