letter = "Dear \"Harry\",\n\tThis python course is amazing.  \n\tThanks! "
print(letter)
