letter = '''Dear sir <name>,
you are selected
date: <date>'''

print(letter.replace("<name>" , "Shaheer").replace("<date>" , "20 August 2029"))