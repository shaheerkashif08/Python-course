a = 58
b = 5
print("the Remainder of a after dividing by b is :" , a % b )