# Arithmetic operator( + , - , * , /)
a = 25 
b = 12 

c = a + b
print(c)

# Assignmennt operator( = , += , -= , *= , /= )
a = 12
b = 16 

a += 2 # incrememt in the value of a and assign it to a
b -= 4 # decrement in the value of b and assign it to b
 
print(a)
print(b)

# Comparision operator( == , <= , >= , < , > , !=)

a = 10 
b = 13

print(a==b)
print(a<b)
print(a>b)
print(a!=b)

# Logical operator( and , or , not)

# Truth table of 'or'
print("True or False is", True or False )
print("False or True is", False or True )
print("False or False is", False or False )
print("True or True is", True or True )

# Truth table of 'and'
print("True and False is", True and False )
print("False and True is", False and True )
print("False and False is", False and False )
print("True and True is", True and True )

print(not(True))
