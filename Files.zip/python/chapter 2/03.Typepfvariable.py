a = 31
b = float(a) # type can be change into other if valid
t = type(b)
print("type of a is",t)

d = "Shaheer"
g = type(d)
print("type of d is",g)


