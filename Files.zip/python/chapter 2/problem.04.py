a = int(input("Enter the first number:"))
b = int(input("Enter the second number:"))

print("The average of first and second number is: " , (a+b)/2)