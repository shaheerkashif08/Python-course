# a = int(input("Enter your number:"))
# print("The square of given number: ", a**2)
# print("The square of given number: ", a*a)

# for taking square roots 
import math

# Ask the user to input a number
number = float(input("Enter a number: "))

# Calculate the square root
square_root = math.sqrt(number)

# Display the result
print(f"The square root of {number} is {square_root}")