 a = 25 # a is an integer 
 b = 28.38 # b is a floating point number
 c = "shaheer" # c is a string
 d = False # d is a boolean variable 
 e = None # e is a none vaiable

 