a = input("Enter a number")
print(type(a))