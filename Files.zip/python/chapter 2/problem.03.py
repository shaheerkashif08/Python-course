a = int(input("Enter the first number:"))
b = int(input("Enter the second number:"))

print("a is greter than b is ", a>b)