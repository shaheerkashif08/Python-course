# write a program to accept marks of 6 student and display them in sorted manner
marks = []


s1 = 24
marks.append(s1)

s2 = 17.5
marks.append(s2)

s3 = 19
marks.append(s3)

s4 = 28.25
marks.append(s4)

s5 = 18
marks.append(s5)

s6 = 14
marks.append(s6)

marks.sort()
print(marks)