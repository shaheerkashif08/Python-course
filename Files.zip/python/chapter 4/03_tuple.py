a = (1,34.43,"Shaheer",True,965)
print(a)
print(type(a))

