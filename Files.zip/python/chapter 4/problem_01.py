# write a program to stores seven fruits in a list entered by a user 
fruits = []
f1 = input("Enter 1rst fruit: ")
fruits.append(f1)

f2 = input("Enter 2nd fruit: ")
fruits.append(f2)

f3 = input("Enter 3rd fruit: ")
fruits.append(f3)

f4 = input("Enter 4th fruit: ")
fruits.append(f4)

f5 = input("Enter 5th fruit: ")
fruits.append(f5)

f6 = input("Enter 6th fruit: ")
fruits.append(f6)

f7 = input("Enter 7th fruit: ")
fruits.append(f7)

print(fruits)