my_tuple = (1, 2, 3, 2, 4, 2)
print(my_tuple.count(2))  # count the number of repeated element

print(my_tuple.index(3)) # print the index of an element

print(my_tuple[3])  # indexing in tuple
print(my_tuple[1:5]) # slicing in tuple

print(2 in my_tuple)  # check whether the 2 is present in my_tuple
print(5 in my_tuple)  # check whether the 5 is present in my_tuple

tuple1 = (1,2)
tuple2 = (3,4,5)
print(tuple1 + tuple2) # Adding two or more tuple

print(tuple1*3) # multiply the tuple by 3 result in 3 times of tuple1