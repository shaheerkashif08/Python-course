friends = ["apple", "orange", 5, 367.034, False, "akash", "Rohan"]
print(friends[0])
friends[0] = "grapes"
print(friends[0])

# list slicing
print(friends[1 : 6 ])
print(friends[1 : 6 : 2])