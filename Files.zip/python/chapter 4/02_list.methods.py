friends = ["apple", "orange", 5, 367.034, False, "akash", "Rohan"]
friends.remove("orange") #append method
print(friends)

l1 = [34, 42, 12, 23, 34, 62, 21,28] 
l1.sort()      # sort merhod
print(l1)

friends.reverse()   # reverse method
print(friends)

friends.insert(3 , 246.28)  # insert 246.28 such that it index is 3
print(friends) 

friends.insert(4, 345)
print(friends)

print(friends.pop(3))  # only print the index 3 element
print(friends)    # delete the 3 index element

friends.pop(1)
print(friends)

friends.remove("Rohan") #remove an element
print(friends)

