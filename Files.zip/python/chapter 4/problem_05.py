# Count the number of zeros in following tuple

a = (7, 0, 8, 0, 0, 9)
b = a.count(0)
print(b)