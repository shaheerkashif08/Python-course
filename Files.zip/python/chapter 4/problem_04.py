numbers = []

n1 = int(input("Enter the number: "))
numbers.append(n1)

n2 = int(input("Enter the number: "))
numbers.append(n2)

n3 = int(input("Enter the number: "))
numbers.append(n3)

n4 = int(input("Enter the number: "))
numbers.append(n4)

print(sum(numbers))