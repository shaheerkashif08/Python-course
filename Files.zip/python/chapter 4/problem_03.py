# Check that a type cannot be changed in python 

my_tuple = (0,2,54,35)
my_tuple[2] = 46

print(my_tuple)  #Hence proved!