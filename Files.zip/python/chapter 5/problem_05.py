'''s = {}
what is the type of s '''

s = {}
print(type(s))