'''Create a empty dictionary. Allow 4 friends to enter the favourite language as values and 
use key as their names. Assume that names are unique'''

d = {}

name = input('Enter the name: ')
lang = input('Enter the language: ')
d.update({name : lang})

name = input('Enter the name: ')
lang = input('Enter the language: ')
d.update({name : lang})

name = input('Enter the name: ')
lang = input('Enter the language: ')
d.update({name : lang})

name = input('Enter the name: ')
lang = input('Enter the language: ')
d.update({name : lang})

print(d)