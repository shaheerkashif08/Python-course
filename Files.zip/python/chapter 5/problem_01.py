# Write a program to create a dictionary of hindi words with values as their english translation. provide user with an option to look it up! 
words = {
    "madad" : "Help",
    "bartan" : "Crockery",
    "billi" : "Cat",
    "ustaad" : "Teacher"
}
word = input("Enter the word: ")
print(words[word])