# Can you change the value in a list which is contaied in set S ?

s = {8, 7, 12, "Shaheer", [1,2]} '''As we can not change the value inside a list contain in a set.Infact 
                   we can't iclude list in set because all element of set should be immutable'''