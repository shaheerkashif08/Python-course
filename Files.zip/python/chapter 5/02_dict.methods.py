marks = {
    "Shaheer" : 100,
    "Tanesh" : 89,
    "Farhan" : 82,
    0 : "Hasnat"
}
print(marks.items())
print(marks.keys())
print(marks.values())
marks.update({"Shaheer" : 99, "Rahim" : 100})
print(marks)

print(marks.get("Rahim2"))  # Prints None if key is not present 
# print(marks("Rahim2"))  # Return n error if key is not present 

delete = marks.pop(0)
print(delete)

print(marks.clear())