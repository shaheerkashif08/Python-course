'''What will be the lenght of following s set:
    s = set()
    s.add(20)
    s.add(20.0)
    s.add('20')  len of s after these operation'''

s = set()
s.add(20)
s.add(20.0)
s.add('20')
print(s, len(s))    