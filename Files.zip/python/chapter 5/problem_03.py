# Can we have a set wit 18(int) and '18'(str) as value in it
s = set()

n1 = input('Enter the number: ')
s.add(int(n1))
n2 = input('Enter the number: ')
s.add(int(n2))
n3 = input('Enter the number: ')
s.add(n3)
print(s)