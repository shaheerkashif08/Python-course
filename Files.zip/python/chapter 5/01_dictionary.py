d = {}    # Empty dictionary
marks = {
    "Shaheer" : 100,
    "Tanesh" : 89,
    "Farhan" : 82
}
print(marks, type(marks))
print(marks['Farhan'])
print(d, type(d))