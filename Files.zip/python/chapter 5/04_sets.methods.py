s = {1,2,3,4,5,2,3,2,'shaheer'}
print(s)

s.add(45)  # Add an element in set
print(s)

s.remove(4)  # remove an element from set
print(s)

s.pop()  # remove a random element of a set 
print(s)

s.clear()  # clear the set result in empty set
print(s)