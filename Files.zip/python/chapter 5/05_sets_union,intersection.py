s ={3, 2, 5, 7, 1}
print(s.union({6, 11, 9}))
print(s.intersection({2, 6, 5, 1}))

s1 = {1, 6,7}
s2 = {7,8,1,78,6}
print(s1.union(s2))
print(s1.intersection(s2))
print(s1.difference(s2))
print(s1.symmetric_difference(s2))
print(s1.issubset(s2))
